# Employee Management Web Application

## Features
- Login
- Sign up
- Dashboard
- Add employee
- View employees
- Update employee
- Delete employee
- Spring Boot backend
- MySQL database
- Postman API testing
- HTML, CSS and JavaScript frontend

## Database
The backend automatically creates the database if MySQL is running.

Default connection:
- Port: 3307
- Database: employee_management_db
- Username: root
- Password: Rollsroyce@12

If your MySQL uses a different password or port, edit:
backend/src/main/resources/application.properties

## Run Backend
Open terminal inside backend folder:

mvn spring-boot:run

Backend URL:
http://localhost:8080

## Run Frontend
Open frontend/index.html in VS Code using Live Server.

## Postman APIs

### Signup
POST http://localhost:8080/api/auth/signup

Body:
{
  "name": "Admin",
  "email": "admin@gmail.com",
  "password": "12345"
}

### Login
POST http://localhost:8080/api/auth/login

Body:
{
  "email": "admin@gmail.com",
  "password": "12345"
}

### Add Employee
POST http://localhost:8080/api/employees

Body:
{
  "firstName": "Aadhithya",
  "lastName": "U",
  "email": "aadhithya@gmail.com",
  "phone": "9876543210",
  "department": "IT",
  "designation": "Developer",
  "salary": 35000
}

### Get All Employees
GET http://localhost:8080/api/employees

### Get Employee By ID
GET http://localhost:8080/api/employees/1

### Update Employee
PUT http://localhost:8080/api/employees/1

Body:
{
  "firstName": "Aadhithya",
  "lastName": "U",
  "email": "aadhithya@gmail.com",
  "phone": "9999999999",
  "department": "HR",
  "designation": "Manager",
  "salary": 50000
}

### Delete Employee
DELETE http://localhost:8080/api/employees/1
