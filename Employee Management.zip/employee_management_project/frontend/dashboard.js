// dashboard.js

const API_BASE = "http://localhost:8080/api/employees";

if (sessionStorage.getItem("loggedIn") !== "true") {
    window.location.href = "index.html";
}

const employeeGrid = document.getElementById("employeeGrid");
const employeeForm = document.getElementById("employeeForm");
const employeeModal = document.getElementById("employeeModal");
const employeeCount = document.getElementById("employeeCount");
const searchInput = document.getElementById("searchInput");

let employeesData = [];

/* LOAD EMPLOYEES */

async function loadEmployees() {

    const response = await fetch(API_BASE);
    const employees = await response.json();

    employeesData = employees;

    employeeCount.textContent = employees.length;

    renderEmployees(employees);
}

/* RENDER */

function renderEmployees(employees) {

    employeeGrid.innerHTML = "";

    employees.forEach(employee => {

        const card = document.createElement("div");

        card.className = "employee-card";

        card.innerHTML = `
    
      <div class="employee-top">
        <div class="avatar">
          ${employee.firstName.charAt(0)}
        </div>

        <div class="badge">
          ${employee.department || "General"}
        </div>
      </div>

      <h3>
        ${employee.firstName} ${employee.lastName}
      </h3>

      <p>${employee.designation || "Employee"}</p>

      <div class="employee-info">
        <span>📧 ${employee.email}</span>
        <span>📱 ${employee.phone || "-"}</span>
        <span>💰 ₹${employee.salary || 0}</span>
      </div>

      <div class="employee-actions">
        <button class="edit-btn"
          onclick='editEmployee(${JSON.stringify(employee)})'>
          Edit
        </button>

        <button class="delete-btn"
          onclick='deleteEmployee(${employee.id})'>
          Delete
        </button>
      </div>
    
    `;

        employeeGrid.appendChild(card);
    });
}

/* MODAL */

function openModal() {
    employeeModal.classList.remove("hidden");
}

function closeModal() {
    employeeModal.classList.add("hidden");
    resetForm();
}

/* FORM */

employeeForm.addEventListener("submit", async (e) => {

    e.preventDefault();

    const employeeId = document.getElementById("employeeId").value;

    const employee = {
        firstName: firstName.value,
        lastName: lastName.value,
        email: email.value,
        phone: phone.value,
        department: department.value,
        designation: designation.value,
        salary: Number(salary.value)
    };

    if (employeeId) {

        await fetch(`${API_BASE}/${employeeId}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(employee)
        });

    } else {

        await fetch(API_BASE, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(employee)
        });
    }

    closeModal();
    loadEmployees();
});

/* EDIT */

function editEmployee(employee) {

    openModal();

    document.getElementById("modalTitle").textContent = "Update Employee";

    employeeId.value = employee.id;
    firstName.value = employee.firstName;
    lastName.value = employee.lastName;
    email.value = employee.email;
    phone.value = employee.phone || "";
    department.value = employee.department || "";
    designation.value = employee.designation || "";
    salary.value = employee.salary || "";
}

/* DELETE */

async function deleteEmployee(id) {

    if (confirm("Delete employee?")) {

        await fetch(`${API_BASE}/${id}`, {
            method: "DELETE"
        });

        loadEmployees();
    }
}

/* RESET */

function resetForm() {

    employeeForm.reset();

    document.getElementById("modalTitle").textContent =
        "Add Employee";

    employeeId.value = "";
}

/* SEARCH */

searchInput.addEventListener("input", (e) => {

    const keyword = e.target.value.toLowerCase();

    const filtered = employeesData.filter(emp =>

        emp.firstName.toLowerCase().includes(keyword) ||
        emp.lastName.toLowerCase().includes(keyword) ||
        emp.department?.toLowerCase().includes(keyword)
    );

    renderEmployees(filtered);
});

/* LOGOUT */

function logout() {

    sessionStorage.clear();

    window.location.href = "index.html";
}

/* START */

loadEmployees();