const API_BASE = "http://localhost:8080/api/auth";

const loginForm = document.getElementById("loginForm");
const signupForm = document.getElementById("signupForm");
const message = document.getElementById("message");
const tabButtons = document.querySelectorAll(".tab-buttons button");

function showLogin() {
    loginForm.classList.remove("hidden");
    signupForm.classList.add("hidden");
    tabButtons[0].classList.add("active");
    tabButtons[1].classList.remove("active");
    message.textContent = "";
}

function showSignup() {
    signupForm.classList.remove("hidden");
    loginForm.classList.add("hidden");
    tabButtons[1].classList.add("active");
    tabButtons[0].classList.remove("active");
    message.textContent = "";
}

signupForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const user = {
        name: document.getElementById("signupName").value,
        email: document.getElementById("signupEmail").value,
        password: document.getElementById("signupPassword").value
    };

    const response = await fetch(`${API_BASE}/signup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
    });

    const result = await response.text();
    message.textContent = result;

    if (result === "Signup successful") {
        signupForm.reset();
        showLogin();
    }
});

loginForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const user = {
        email: document.getElementById("loginEmail").value,
        password: document.getElementById("loginPassword").value
    };

    const response = await fetch(`${API_BASE}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
    });

    const result = await response.text();
    message.textContent = result;

    if (result === "Login successful") {
        sessionStorage.setItem("loggedIn", "true");
        sessionStorage.setItem("userEmail", user.email);
        window.location.href = "dashboard.html";
    }
});
